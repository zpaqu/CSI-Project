#include "SplitFour.h"

//Auteurs: Nicolas Daigle (7223444), Zachary Paquette (7230016)
//Cours: CSI2772
//Date de remise: 9 Decembre 2015

SplitFour::SplitFour(char a, char b, char c, char d) : AnimalCard(a,b,c,d)
{
	animalNumber = 4;
}

SplitFour::~SplitFour()
{
	
}
