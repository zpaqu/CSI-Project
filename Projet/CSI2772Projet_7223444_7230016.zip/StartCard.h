#pragma once
#include "NoSplit.h"

//Auteurs: Nicolas Daigle (7223444), Zachary Paquette (7230016)
//Cours: CSI2772
//Date de remise: 9 Decembre 2015

class StartCard : public NoSplit
{
public:
	StartCard();
	~StartCard();

private:

};
