#include "StartCard.h"

//Auteurs: Nicolas Daigle (7223444), Zachary Paquette (7230016)
//Cours: CSI2772
//Date de remise: 9 Decembre 2015

StartCard::StartCard():NoSplit('c')
{
	animalNumber = 0;
}

StartCard::~StartCard()
{

}